Place the selected e-commerce dataset here and rename the main CSV to orders.csv.

Expected common fields:
order_id, customer_id, order_date, product_id, category,
quantity, unit_price, discount, payment_type,
customer_location, rating, delivery_days, revenue

If your dataset uses different names, update src/data_preprocessing.py.
