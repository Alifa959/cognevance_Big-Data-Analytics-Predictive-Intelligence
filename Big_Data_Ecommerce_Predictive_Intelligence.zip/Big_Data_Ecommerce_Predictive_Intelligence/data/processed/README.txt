Generated files such as clean_orders.csv, monthly_sales.csv, customer_features.csv and sales_forecast.csv will be stored here.
